SELECT * FROM owner2.shop;
use owner2;
